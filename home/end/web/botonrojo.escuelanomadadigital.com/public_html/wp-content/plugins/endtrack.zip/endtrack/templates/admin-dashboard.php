<style>
    :root {
        --endtrack-primary: #6366f1;
        --endtrack-secondary: #06b6d4;
        --endtrack-bg: #f0f2f5;
        --endtrack-card: rgba(255, 255, 255, 0.65);
        --endtrack-card-solid: #ffffff;
        --endtrack-text: #1a1a2e;
        --endtrack-text-muted: #6b7280;
        --endtrack-border: rgba(255, 255, 255, 0.5);
        --endtrack-accent: #818CF8;
        --endtrack-glass: rgba(255, 255, 255, 0.45);
        --endtrack-glass-border: rgba(255, 255, 255, 0.6);
        --endtrack-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
        --endtrack-blur: blur(20px);
    }

    /* Loader Overlay */
    .endtrack-loader-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(15, 23, 42, 0.8);
        backdrop-filter: blur(4px);
        z-index: 99999;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        color: white;
        text-align: center;
    }

    .endtrack-loader-content {
        max-width: 400px;
        padding: 40px;
    }

    .pizza-loader {
        font-size: 80px;
        margin-bottom: 20px;
        animation: rotate 2s linear infinite;
        display: inline-block;
    }

    @keyframes rotate {
        from {
            transform: rotate(0deg);
        }

        to {
            transform: rotate(360deg);
        }
    }

    .loader-text h3 {
        font-size: 24px;
        margin: 0 0 10px 0;
        color: white;
    }

    .loader-text p {
        font-size: 16px;
        opacity: 0.8;
        line-height: 1.5;
    }

    .endtrack-wrap {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        color: var(--endtrack-text);
        max-width: 1400px;
        margin: 20px auto;
        background: var(--endtrack-bg);
        border-radius: 24px;
        padding: 30px;
        border: none;
        box-shadow: none;
    }

    .endtrack-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        border-bottom: none;
        padding-bottom: 20px;
    }

    .endtrack-header img {
        max-width: 250px;
        display: block;
    }

    .endtrack-header h1 {
        font-size: 28px;
        font-weight: 800;
        background: linear-gradient(to right, var(--endtrack-primary), var(--endtrack-secondary));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 0;
    }

    .endtrack-nav {
        display: flex;
        gap: 10px;
        margin-bottom: 30px;
    }

    .endtrack-nav a {
        text-decoration: none;
        padding: 10px 20px;
        border-radius: 14px;
        font-weight: 600;
        color: var(--endtrack-text-muted);
        transition: all 0.3s ease;
        background: var(--endtrack-glass);
        backdrop-filter: var(--endtrack-blur);
        border: 1px solid var(--endtrack-glass-border);
    }

    .endtrack-nav a:hover {
        background: rgba(99, 102, 241, 0.1);
        color: var(--endtrack-primary);
    }

    .endtrack-nav a.active {
        background: var(--endtrack-primary);
        color: white;
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.35);
        border-color: transparent;
    }

    .endtrack-card {
        background: var(--endtrack-card);
        backdrop-filter: var(--endtrack-blur);
        -webkit-backdrop-filter: var(--endtrack-blur);
        border-radius: 20px;
        padding: 24px;
        border: 1px solid var(--endtrack-glass-border);
        box-shadow: var(--endtrack-shadow);
        margin-bottom: 24px;
    }

    .endtrack-card h2 {
        font-size: 1.25rem;
        font-weight: 700;
        margin-top: 0;
        margin-bottom: 20px;
        color: var(--endtrack-text);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .endtrack-table {
        width: 100%;
        border-collapse: collapse;
    }

    .endtrack-table th {
        text-align: left;
        padding: 12px 16px;
        background: rgba(241, 245, 249, 0.6);
        backdrop-filter: blur(10px);
        font-weight: 600;
        color: var(--endtrack-text-muted);
        text-transform: uppercase;
        font-size: 0.75rem;
        letter-spacing: 0.05em;
    }

    .endtrack-table td {
        padding: 16px;
        border-bottom: 1px solid rgba(226, 232, 240, 0.5);
    }

    .endtrack-input {
        width: 100%;
        padding: 8px 12px;
        border-radius: 12px;
        border: 1px solid rgba(0, 0, 0, 0.08);
        background: rgba(255, 255, 255, 0.7);
        backdrop-filter: blur(10px);
        transition: all 0.3s ease;
    }

    .endtrack-input:focus {
        outline: none;
        border-color: var(--endtrack-primary);
        box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.12);
        background: rgba(255, 255, 255, 0.9);
    }

    .btn-primary {
        background: var(--endtrack-primary);
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 2px 10px rgba(99, 102, 241, 0.25);
    }

    .btn-primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.35);
    }

    .btn-outline {
        border: 1.5px solid rgba(99, 102, 241, 0.3);
        color: var(--endtrack-primary);
        background: var(--endtrack-glass);
        backdrop-filter: blur(10px);
        padding: 10px 20px;
        border-radius: 14px;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: all 0.3s ease;
    }

    .btn-outline:hover {
        background: rgba(99, 102, 241, 0.08);
        border-color: var(--endtrack-primary);
    }

    .instruction-step {
        display: flex;
        gap: 16px;
        margin-bottom: 20px;
    }

    .step-number {
        background: var(--endtrack-primary);
        color: white;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        flex-shrink: 0;
    }

    .badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.75rem;
        font-weight: 700;
        background: #E0E7FF;
        color: var(--endtrack-primary);
        margin-right: 5px;
    }

    .badge-registration {
        background: #DBEAFE;
        color: #1E40AF;
    }

    .badge-direct {
        background: #D1FAE5;
        color: #065F46;
    }

    /* Emergency Button Styles */
    .btn-emergency-container {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        padding: 40px;
        gap: 60px;
    }

    .btn-creation-fields {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 25px;
    }

    .btn-emergency {
        position: relative;
        display: inline-block;
        width: 220px;
        height: 220px;
        background: #dc2626;
        border: 10px solid #991b1b;
        border-radius: 50%;
        color: white;
        font-family: 'Inter', sans-serif;
        font-size: 24px;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 1px;
        cursor: pointer;
        box-shadow:
            0 15px 0 #991b1b,
            0 20px 25px -5px rgba(0, 0, 0, 0.5);
        transition: all 0.1s;
        outline: none;
        user-select: none;
        margin-bottom: 25px;
    }

    .btn-emergency:hover {
        background: #ef4444;
    }

    .btn-emergency:active {
        box-shadow:
            0 5px 0 #991b1b,
            0 5px 15px -5px rgba(0, 0, 0, 0.5);
        transform: translateY(10px);
    }

    .btn-emergency::before {
        content: "";
        position: absolute;
        top: 10%;
        left: 15%;
        width: 70%;
        height: 35%;
        background: rgba(255, 255, 255, 0.2);
        border-radius: 50% 50% 40% 40%;
    }

    .btn-emergency-base {
        background: #4b5563;
        padding: 15px 30px;
        border-radius: 12px;
        border-bottom: 8px solid #1f2937;
        display: inline-flex;
        flex-direction: column;
        align-items: center;
    }

    /* Futuristic Modal */
    .endtrack-modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(15, 23, 42, 0.9);
        backdrop-filter: blur(10px);
        z-index: 100000;
        align-items: center;
        justify-content: center;
    }

    .endtrack-modal {
        background: #0f172a;
        width: 100%;
        max-width: 500px;
        padding: 40px;
        border-radius: 24px;
        border: 1px solid rgba(129, 140, 248, 0.3);
        box-shadow: 0 0 50px rgba(79, 70, 229, 0.2), inset 0 0 20px rgba(79, 70, 229, 0.1);
        position: relative;
        overflow: hidden;
    }

    .endtrack-modal::before {
        content: "";
        position: absolute;
        top: -100px;
        left: -100px;
        width: 200px;
        height: 200px;
        background: radial-gradient(circle, rgba(79, 70, 229, 0.4) 0%, transparent 70%);
        z-index: 0;
    }

    .endtrack-modal-header {
        position: relative;
        z-index: 2;
        margin-bottom: 25px;
    }

    .endtrack-modal-header h2 {
        color: white;
        margin: 0;
        font-size: 24px;
        text-transform: uppercase;
        letter-spacing: 2px;
        font-weight: 800;
        text-shadow: 0 0 10px rgba(79, 70, 229, 0.5);
    }

    .endtrack-modal-content {
        position: relative;
        z-index: 2;
    }

    .endtrack-modal-footer {
        margin-top: 30px;
        display: flex;
        gap: 12px;
        justify-content: flex-end;
        position: relative;
        z-index: 2;
    }

    .endtrack-btn-neon {
        background: var(--endtrack-primary);
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 12px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 1px;
        cursor: pointer;
        box-shadow: 0 0 15px rgba(79, 70, 229, 0.4);
        transition: all 0.3s;
    }

    .endtrack-btn-neon:hover {
        transform: translateY(-2px);
        box-shadow: 0 0 25px rgba(79, 70, 229, 0.6);
    }

    .endtrack-btn-cancel {
        background: transparent;
        color: #94a3b8;
        border: 1px solid #334155;
        padding: 12px 24px;
        border-radius: 12px;
        font-weight: 600;
        cursor: pointer;
    }

    /* Modern Settings Layout */
    .settings-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 24px;
        margin-top: 20px;
    }

    .settings-section-card {
        background: var(--endtrack-card);
        backdrop-filter: var(--endtrack-blur);
        border: 1px solid var(--endtrack-glass-border);
        border-radius: 20px;
        overflow: hidden;
        box-shadow: var(--endtrack-shadow);
        display: flex;
        flex-direction: column;
    }

    .settings-section-header {
        background: rgba(248, 250, 252, 0.5);
        backdrop-filter: blur(10px);
        padding: 16px 20px;
        border-bottom: 1px solid rgba(226, 232, 240, 0.4);
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .settings-section-header h3 {
        margin: 0 !important;
        font-size: 16px !important;
        font-weight: 700 !important;
        color: var(--endtrack-text) !important;
        border-bottom: none !important;
        padding-bottom: 0 !important;
    }

    .settings-section-content {
        padding: 20px;
        flex-grow: 1;
    }

    .settings-row {
        margin-bottom: 20px;
    }

    .settings-row:last-child {
        margin-bottom: 0;
    }

    .settings-row label {
        display: block;
        font-weight: 600;
        margin-bottom: 8px;
        color: var(--endtrack-text-muted);
        font-size: 13px;
    }

    .settings-row .description {
        margin-top: 4px;
        font-size: 12px;
        color: var(--endtrack-text-muted);
    }

    .full-width-editor {
        grid-column: 1 / -1;
    }

    /* Rainbow Border Effect */
    .rainbow-border-wrap {
        position: relative;
        padding: 3px;
        border-radius: 12px;
        overflow: hidden;
        width: 100%;
        display: flex;
        box-sizing: border-box;
    }

    .rainbow-border-wrap::before {
        content: '';
        position: absolute;
        top: -150%;
        left: -150%;
        width: 400%;
        height: 400%;
        background: conic-gradient(#fffb00, #FF72FF, #69aff2, #aa69e7);
        animation: rotate-rainbow 3s linear infinite;
        z-index: 0;
    }

    @keyframes rotate-rainbow {
        100% {
            transform: rotate(360deg);
        }
    }

    .endtrack-input {
        box-sizing: border-box;
    }

    /* Toggle Switch */
    .switch {
        position: relative;
        display: inline-block;
        width: 50px;
        height: 24px;
    }

    .switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .4s;
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        transition: .4s;
    }

    input:checked+.slider {
        background-color: #10b981;
    }

    input:focus+.slider {
        box-shadow: 0 0 1px #10b981;
    }

    input:checked+.slider:before {
        transform: translateX(26px);
    }

    .slider.round {
        border-radius: 24px;
    }

    .slider.round:before {
        border-radius: 50%;
    }

    /* Modern Full Screen Loader */
    #endtrack-creation-loader {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: conic-gradient(#fffb00, #FF72FF, #69aff2, #aa69e7);
        z-index: 999999;
        display: none;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
        background-size: 200% 200%;
        animation: gradient-spin 4s linear infinite;
    }

    @keyframes gradient-spin {
        0% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }

        100% {
            background-position: 0% 50%;
        }
    }

    /* To make the conic gradient actually "move" nicely, standard conic-gradient is hard to animate directly with background-position in some browsers without pseudo-elements, 
       but let's try a rotating pseudo-element or just the raw gradient if the user accepts a simple spin. 
       Actually, the user asked for a "moving" loader. Let's make the background itself obscurely moving 
       or add a spinning ring.
       Let's stick to the requested colors in a conic gradient and maybe rotate the whole background?
       Or better: Use a CSS animation on the background image if it was linear, but for conic we usually rotate the container or a pseudo.
       Let's try a rotating background effect.
    */

    #endtrack-creation-loader::before {
        content: "";
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: conic-gradient(#fffb00, #FF72FF, #69aff2, #aa69e7);
        animation: spin-conic 4s linear infinite;
        z-index: -1;
    }

    @keyframes spin-conic {
        from {
            transform: rotate(0deg);
        }

        to {
            transform: rotate(360deg);
        }
    }

    #endtrack-creation-loader h1 {
        color: white;
        font-size: 3.5rem;
        font-weight: 900;
        text-transform: uppercase;
        max-width: 90%;
        line-height: 1.2;
        text-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        position: relative;
        z-index: 10;
        margin: 0;
        padding: 20px;
    }

    /* A simple spinner icon for extra movement */
    .pizza-spinner {
        font-size: 60px;
        animation: bounce 1s infinite alternate;
        margin-bottom: 30px;
        z-index: 10;
    }

    @keyframes bounce {
        from {
            transform: translateY(0);
        }

        to {
            transform: translateY(-20px);
        }
    }

    /* AI Queue Progress Overlay */
    #endtrack-ai-queue-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(15, 23, 42, 0.92);
        backdrop-filter: blur(8px);
        z-index: 999999;
        display: none;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
        color: white;
        font-family: 'Inter', sans-serif;
    }

    #endtrack-ai-queue-overlay .queue-content {
        max-width: 500px;
        padding: 40px;
    }

    #endtrack-ai-queue-overlay .queue-icon {
        font-size: 64px;
        margin-bottom: 20px;
        animation: bounce 1s infinite alternate;
    }

    #endtrack-ai-queue-overlay h2 {
        font-size: 1.8rem;
        font-weight: 800;
        margin: 0 0 10px 0;
        color: white;
    }

    #endtrack-ai-queue-overlay .queue-status {
        font-size: 1rem;
        opacity: 0.85;
        margin-bottom: 30px;
    }

    #endtrack-ai-queue-overlay .queue-progress-bar {
        width: 100%;
        height: 12px;
        background: rgba(255, 255, 255, 0.15);
        border-radius: 6px;
        overflow: hidden;
        margin-bottom: 20px;
    }

    #endtrack-ai-queue-overlay .queue-progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #6366f1, #06b6d4);
        border-radius: 6px;
        transition: width 0.5s ease;
        width: 0%;
    }

    #endtrack-ai-queue-overlay .queue-log {
        text-align: left;
        font-size: 0.85rem;
        max-height: 200px;
        overflow-y: auto;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 10px;
        padding: 15px;
        margin-top: 15px;
    }

    #endtrack-ai-queue-overlay .queue-log-entry {
        padding: 4px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        opacity: 0.8;
    }

    #endtrack-ai-queue-overlay .queue-log-entry.success {
        color: #4ade80;
    }

    #endtrack-ai-queue-overlay .queue-log-entry.error {
        color: #f87171;
    }

    #endtrack-ai-queue-overlay .queue-log-entry.processing {
        color: #60a5fa;
    }

    .btn-ai-page {
        background: #F1F5F9;
        color: var(--endtrack-text);
        border: none;
        width: 28px;
        height: 28px;
        border-radius: 6px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s;
        margin-left: 5px;
        vertical-align: middle;
    }

    .btn-ai-page:hover {
        background: var(--endtrack-primary);
        color: white;
    }

    .btn-ai-page .dashicons {
        font-size: 16px;
        width: 16px;
        height: 16px;
    }
</style>

<!-- Custom Loader Overlay -->
<div class="endtrack-loader-overlay" id="endtrackLoader">
    <div class="endtrack-loader-content">
        <div class="pizza-loader">🍕</div>
        <div class="loader-text">
            <h3>Trabajando en ello...</h3>
            <p>En menos que Irene te pone 10 tareas de Notion se harán los cambios. ¡Paciencia!</p>
        </div>
    </div>
</div>

<!-- Futuristic AI Popup -->
<div class="endtrack-modal-overlay" id="endtrackAIModal">
    <div class="endtrack-modal">
        <div class="endtrack-modal-header">
            <h2 id="endtrackModalTitle">AI DESIGN & COPY ENGINE</h2>
        </div>
        <div class="endtrack-modal-content">
            <label
                style="color: #cbd5e1; display: block; margin-bottom: 12px; font-weight: 600; font-size: 14px;">INTRODUCE
                ÓRDENES DE DISEÑO O TEXTO:</label>
            <textarea id="endtrackAIPromptInput" class="endtrack-input" rows="5"
                style="background: #1e293b; border-color: #334155; color: white; padding: 15px; font-size: 15px;"
                placeholder="Ej: Modifica el bloque 'Ventas' con fondo azul y añade un botón rojo debajo del título..."></textarea>
        </div>
        <div class="endtrack-modal-footer">
            <button type="button" class="endtrack-btn-cancel" id="closeAIModal">CANCELAR</button>
            <button type="button" class="endtrack-btn-neon" id="confirmAIPrompt">EJECUTAR IA</button>
        </div>
    </div>
</div>

<div class="endtrack-wrap">
    <header class="endtrack-header">
        <?php
$logo_src = !empty($texts['logo_admin_panel']) ? esc_url($texts['logo_admin_panel']) : '';
if ($logo_src): ?>
        <img src="<?php echo $logo_src; ?>" alt="Logo">
        <?php
else: ?>
        <img src="<?php echo plugin_dir_url(dirname(__FILE__)) . 'END_track.webp'; ?>" alt="ENDTrack"
            style="max-height: 40px; width: auto;">
        <?php
endif; ?>
        <div style="display: flex; gap: 15px; align-items: center;">
            <a href="<?php echo site_url('/endtrack-panel-admin-afiliado/'); ?>" target="_blank" class="btn-outline">
                <span class="dashicons dashicons-chart-bar" style="margin-top: 4px;"></span>
                Panel de Administración de Afiliados
            </a>
            <a href="<?php echo home_url('/endtrack-estadisticas/'); ?>" target="_blank" class="btn-outline"
                style="border-color: #6366f1; color: #6366f1;">
                <span class="dashicons dashicons-chart-line" style="margin-top: 4px;"></span>
                Estadísticas Pro
            </a>
            <!-- <a href="<?php echo home_url('/endtrack-panel-admin-afiliado/'); ?>" target="_blank" class="btn-outline"
                style="border-color: #4F46E5; color: #4F46E5;">
                <span class="dashicons dashicons-editor-expand" style="margin-top: 4px;"></span>
                Panel Afiliados
            </a> -->
            <!-- Grafana buttons removed -->

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="margin: 0;">
                <input type="hidden" name="action" value="endtrack_flush_rewrites">
                <?php wp_nonce_field('endtrack_flush_rewrites_action', 'endtrack_flush_rewrites_nonce'); ?>
                <!-- <button type="submit" class="btn-outline"
                    style="padding: 5px 10px; font-size: 11px; border-color: #94a3b8; color: #64748b;"
                    title="Si los enlaces -endtrack dan 404, pulsa aquí">
                    Corregir Enlaces 404
                </button> -->
            </form>
        </div>
    </header>

    <?php
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'launches';
$launches = get_option('endtrack_launches', array());
$launch_configs = get_option('endtrack_launch_configs', array());
$texts = get_option('endtrack_texts', array());
?>

    <nav class="endtrack-nav">
        <a href="<?php echo add_query_arg('tab', 'launches'); ?>"
            class="<?php echo $active_tab == 'launches' ? 'active' : ''; ?>">Lanzamientos</a>
        <a href="<?php echo add_query_arg('tab', 'texts'); ?>"
            class="<?php echo $active_tab == 'texts' ? 'active' : ''; ?>">Textos y
            Configuración</a>
        <a href="<?php echo add_query_arg('tab', 'integrations'); ?>"
            class="<?php echo $active_tab == 'integrations' ? 'active' : ''; ?>">Integraciones</a>
        <a href="<?php echo add_query_arg('tab', 'help'); ?>"
            class="<?php echo $active_tab == 'help' ? 'active' : ''; ?>">Instrucciones y
            Ayuda</a>
    </nav>

    <?php if (isset($_GET['message'])): ?>
    <div style="margin: 20px 0; padding: 15px; border-radius: 12px; border-left: 6px solid; font-weight: 500; font-size: 15px; 
            <?php
    $m = $_GET['message'];
    if (strpos($m, 'error') !== false || strpos($m, 'fail') !== false) {
        echo 'background: #fef2f2; border-color: #ef4444; color: #991b1b; box-shadow: 0 4px 6px -1px rgba(239, 68, 68, 0.1);';
    }
    else {
        echo 'background: #f0fdf4; border-color: #22c55e; color: #166534; box-shadow: 0 4px 6px -1px rgba(34, 197, 94, 0.1);';
    }
?>">
        <?php
    switch ($_GET['message']) {
        case 'launch_created':
            echo '✅ ¡Lanzamiento creado! Las páginas están listas. Usa el botón 🧠 en cada página para generar el contenido con IA.';
            break;
        case 'launch_created_ai_queued':
            echo '✅ ¡Lanzamiento creado! Generando contenido con IA... No cierres esta página.';
            break;
        case 'ai_generation_complete':
            echo '🎉 ¡Lanzamiento creado y todas las páginas generadas con IA! Ya puedes editarlas.';
            break;
        case 'launch_created_grafana_error':
            echo '⚠️ Lanzamiento creado, pero la conexión con Grafana ha fallado. Revisa tu URL y Token en la pestaña "Integraciones".';
            break;
        case 'integrations_saved':
            echo '✅ Integraciones guardadas correctamente.';
            break;
        case 'texts_saved':
            echo '✅ Configuración de textos y IDs guardada.';
            break;
        case 'launch_deleted':
            echo '🗑️ Lanzamiento eliminado correctamente.';
            break;
        case 'rewrites_flushed':
            echo '🔗 Permalinks de WordPress actualizados correctamente.';
            break;
        default:
            echo 'ℹ️ ' . esc_html($_GET['message']);
            break;
    }
?>
    </div>
    <?php
endif; ?>

    <?php if ($active_tab == 'launches'): ?>

    <?php if (!empty($launches)): ?>
    <div style="margin-bottom: 24px; text-align: right;">
        <button type="button" id="endtrack-toggle-create"
            onclick="var f=document.getElementById('endtrack-create-form');var b=this;if(f.style.display==='none'){f.style.display='block';b.innerHTML='<span class=\'dashicons dashicons-no\' style=\'margin-right:6px;vertical-align:middle;\'></span>Cerrar';}else{f.style.display='none';b.innerHTML='<span class=\'dashicons dashicons-plus-alt2\' style=\'margin-right:6px;vertical-align:middle;\'></span>Nuevo Lanzamiento';}"
            style="background: var(--endtrack-primary); color: white; border: none; padding: 12px 24px; border-radius: 14px; font-weight: 700; font-size: 15px; cursor: pointer; box-shadow: 0 4px 15px rgba(99,102,241,0.3); transition: all 0.3s;">
            <span class="dashicons dashicons-plus-alt2" style="margin-right: 6px; vertical-align: middle;"></span>Nuevo
            Lanzamiento
        </button>
    </div>
    <?php
    endif; ?>

    <div id="endtrack-create-form" class="endtrack-card"
        style="<?php echo !empty($launches) ? 'display:none;' : ''; ?> background: var(--endtrack-glass); border: 1px solid var(--endtrack-glass-border);">
        <h2 style="justify-content: center; font-size: 1.5rem; margin-bottom: 30px;">
            <span class="dashicons dashicons-rocket"
                style="color: var(--endtrack-primary); font-size: 24px; width: 24px; height: 24px;"></span>
            NUEVO LANZAMIENTO
        </h2>

        <script>
            function showEndtrackLoader() {
                const nameInput = document.querySelector('input[name="launch_name"]');
                if (nameInput && nameInput.value.trim() !== '') {
                    document.getEId('endtrack-creation-loader').style.display = 'flex';
                }
            }
        </script>

        <form method="post" onsubmit="showEndtrackLoader()" action="<?php echo admin_url('admin-post.php'); ?>">
            <input type="hidden" name="action" value="endtrack_create_launch">
            <?php wp_nonce_field('endtrack_create_launch_action', 'endtrack_create_launch_nonce'); ?>

            <div class="btn-emergency-container">
                <div class="btn-creation-fields">
                    <div style="display: flex; gap: 20px; width: 100%;">
                        <div style="flex: 2;">
                            <label
                                style="display: block; text-align: left; font-weight: 700; margin-bottom: 8px; color: #475569;">NOMBRE
                                DEL LANZAMIENTO</label>
                            <div class="rainbow-border-wrap" style="height: 60px;">
                                <input type="text" name="launch_name" class="endtrack-input"
                                    placeholder="ej. PGmarzo2025"
                                    style="padding: 0 15px; font-size: 18px; font-weight: 700; text-transform: lowercase; height: 100%; border: none; width: 100%; box-sizing: border-box; position: relative; z-index: 1; background: #fff;"
                                    required>
                            </div>
                        </div>
                        <div style="flex: 1;">
                            <label
                                style="display: block; text-align: left; font-weight: 700; margin-bottom: 8px; color: #475569;">TIPO</label>
                            <select name="launch_type" class="endtrack-input"
                                style="padding: 0 15px; font-size: 16px; height: 60px; width: 100%; box-sizing: border-box;"
                                required>
                                <option value="1">Venta Directa</option>
                                <option value="2">Con Registro</option>
                                <option value="3">Sin crear páginas</option>
                            </select>
                        </div>
                    </div>

                    <!-- URLs de referencia para imitar diseño -->
                    <div id="endtrack-url-fields"
                        style="width: 100%; display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div id="url-field-registro" style="display: none;">
                            <label
                                style="display: block; text-align: left; font-weight: 700; margin-bottom: 8px; color: #475569;">
                                URL DISEÑO — PÁGINA DE SUSCRIPCIÓN
                            </label>
                            <input type="url" name="url_registro" class="endtrack-input"
                                placeholder="https://ejemplo.com/registro" style="padding: 0 15px; height: 50px;">
                            <small style="color: #64748b;">La IA imitará la estructura de esta URL.</small>
                        </div>
                        <div id="url-field-gracias-registro" style="display: none;">
                            <label
                                style="display: block; text-align: left; font-weight: 700; margin-bottom: 8px; color: #475569;">
                                URL DISEÑO — GRACIAS POR REGISTRARTE
                            </label>
                            <input type="url" name="url_gracias_registro" class="endtrack-input"
                                placeholder="https://ejemplo.com/gracias-registro"
                                style="padding: 0 15px; height: 50px;">
                            <small style="color: #64748b;">La IA imitará la estructura de esta URL.</small>
                        </div>
                        <div id="url-field-venta" style="display: none;">
                            <label
                                style="display: block; text-align: left; font-weight: 700; margin-bottom: 8px; color: #475569;">
                                URL DISEÑO — PÁGINA DE VENTA
                            </label>
                            <input type="url" name="url_venta" class="endtrack-input"
                                placeholder="https://ejemplo.com/venta" style="padding: 0 15px; height: 50px;">
                            <small style="color: #64748b;">La IA imitará la estructura de esta URL.</small>
                        </div>
                        <div id="url-field-gracias-compra" style="display: none;">
                            <label
                                style="display: block; text-align: left; font-weight: 700; margin-bottom: 8px; color: #475569;">
                                URL DISEÑO — GRACIAS POR COMPRAR
                            </label>
                            <input type="url" name="url_gracias_compra" class="endtrack-input"
                                placeholder="https://ejemplo.com/gracias-compra" style="padding: 0 15px; height: 50px;">
                            <small style="color: #64748b;">La IA imitará la estructura de esta URL.</small>
                        </div>
                    </div>

                    <!-- AI Prompt Field -->
                    <div style="width: 100%;">
                        <label
                            style="display: block; text-align: left; font-weight: 700; margin-bottom: 8px; color: #475569;">
                            🤖 PROMPT DE IA (OPCIONAL)
                        </label>
                        <textarea name="ai_prompt" class="endtrack-input" rows="4"
                            placeholder="Ej: Genera copy para un curso de marketing digital dirigido a emprendedores..."
                            style="padding: 15px; font-size: 14px; line-height: 1.6; resize: vertical; font-family: inherit;"></textarea>
                        <small style="color: #64748b; display: block; margin-top: 8px;">
                            Si completas este campo, la IA generará automáticamente el copy.
                        </small>
                    </div>

                    <script>
                        (function () { var s = document.querySelector('select[name="launch_type"]'), r = document.getElementById('url-field-registro'), gr = document.getElementById('url-field-gracias-registro'), v = document.getElementById('url-field-venta'), gc = document.getElementById('url-field-gracias-compra'), w = document.getElementById('endtrack-url-fields'); function u() { var t = s.value; r.style.display = t === '2' ? 'block' : 'none'; gr.style.display = t === '2' ? 'block' : 'none'; v.style.display = (t === '1' || t === '2') ? 'block' : 'none'; gc.style.display = (t === '1' || t === '2') ? 'block' : 'none'; w.style.display = t === '3' ? 'none' : 'grid'; } s.addEventListener('change', u); u(); })();
                    </script>

                    <p class="description"
                        style="margin-top: 10px; font-style: italic; text-align: left; color: #94a3b8;">
                        <strong>ATENCIÓN:</strong> Al pulsar el botón gigante se crearán categorías, carpetas y páginas.
                    </p>
                </div>

                <div class="btn-emergency-base" style="transform: scale(1.1);">
                    <button type="submit" class="btn-emergency">CREAR</button>
                    <span style="color: white; font-weight: 800; font-size: 14px; letter-spacing: 2px;">PRESIONA PARA
                        LANZAR</span>
                </div>
            </div>
        </form>
    </div>

    <div class="endtrack-card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="margin: 0;">Lanzamientos Activos y Enlaces</h2>
            <div
                style="background: rgba(255, 251, 235, 0.7); backdrop-filter: blur(10px); border: 1px solid rgba(254, 243, 199, 0.6); color: #92400E; padding: 10px 15px; border-radius: 14px; font-size: 13px; max-width: 500px;">
                <span class="dashicons dashicons-info"
                    style="font-size: 18px; margin-right: 5px; vertical-align: text-bottom;"></span>
                Los checkbox que se marquen en las páginas serán los que aparezcan en el panel de afiliados.
            </div>
        </div>
        <?php
    if (!empty($launches)): ?>
        <table class="endtrack-table">
            <thead>
                <tr>
                    <th>Lanzamiento</th>
                    <th>Visible Afiliados</th>
                    <th>Tipo</th>
                    <th>Páginas Registro</th>
                    <th>Gracias Registro</th>
                    <th>Páginas Venta</th>
                    <th>Páginas Gracias</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($launches as $launch):
            $type_id = isset($launch_configs[$launch]['type']) ? $launch_configs[$launch]['type'] : 1;

            if ($type_id == 3) {
                $type_label = 'Sin crear páginas';
                $type_class = 'badge-direct'; // Or create a new style
            }
            elseif ($type_id == 2) {
                $type_label = 'Con Registro';
                $type_class = 'badge-registration';
            }
            else {
                $type_label = 'Venta Directa';
                $type_class = 'badge-direct';
            }

            // Helper to get pages for this launch + specific type
            // Mapping logic: launch name -> category slug (should be stored in option, but fallback to sanitize)
            $mapping = get_option('endtrack_launches_mapping', array());
            $launch_cat_slug = isset($mapping[$launch]) ? $mapping[$launch] : sanitize_title($launch);

            // Ensure launch category exists before querying
            $launch_cat = get_category_by_slug($launch_cat_slug);

            $get_pages_by_type = function ($type_slug) use ($launch_cat_slug) {
                if (!$launch_cat_slug)
                    return array();

                $args = array(
                    'post_type' => 'page',
                    'posts_per_page' => -1,
                    'tax_query' => array(
                        'relation' => 'AND',
                            array(
                            'taxonomy' => 'category',
                            'field' => 'slug',
                            'terms' => $launch_cat_slug,
                        ),
                            array(
                            'taxonomy' => 'category',
                            'field' => 'slug',
                            'terms' => $type_slug, // registro, venta, gracias
                        ),
                    ),
                );
                return get_posts($args);
            };

            $registros = $get_pages_by_type('registro');
            $gracias_reg = $get_pages_by_type('gracias-registro');
            $ventas = $get_pages_by_type('venta');
            $gracias = $get_pages_by_type('gracias');

            $render_page_list = function ($pages, $type_slug) {
                if (empty($pages))
                    return '<span class="description" style="font-style:italic;">Sin páginas</span>';

                $html = '<div style="display:flex; flex-direction:column; gap:8px;">';
                foreach ($pages as $p) {
                    $edit_url = admin_url('post.php?post=' . $p->ID . '&action=elementor');
                    $view_url = get_permalink($p->ID);
                    $is_affiliate = get_post_meta($p->ID, '_endtrack_is_affiliate_link', true);
                    $checked = $is_affiliate ? 'checked' : '';

                    $html .= '<div style="background:#f8fafc; padding:8px; border-radius:6px; border:1px solid #e2e8f0; position:relative;">';
                    $html .= '<div style="position:absolute; top:8px; right:8px; display:flex; gap:4px; align-items:center;">';
                    $html .= '<input type="checkbox" class="endtrack-affiliate-toggle" data-post-id="' . $p->ID . '" ' . $checked . ' title="Mostrar en panel de afiliados">';
                    $html .= '</div>';
                    $html .= '<div style="font-weight:600; font-size:13px; margin-bottom:4px; padding-right: 45px;">' . esc_html($p->post_title) . '</div>';
                    $html .= '<div style="display:flex; gap:6px;">';
                    $html .= '<a href="' . esc_url($view_url) . '" target="_blank" style="font-size:11px; text-decoration:none; color:#4F46E5; background:#e0e7ff; padding:2px 6px; border-radius:4px;">Ver</a>';
                    $html .= '<a href="' . esc_url($edit_url) . '" target="_blank" style="font-size:11px; text-decoration:none; color:#0f172a; background:#e2e8f0; padding:2px 6px; border-radius:4px;">Elementor</a>';
                    $html .= '</div>';
                    $html .= '</div>';
                }
                $html .= '</div>';
                return $html;
            };
?>
                <tr>
                    <td style="vertical-align:top;">
                        <strong>
                            <?php echo esc_html($launch); ?>
                        </strong>
                        <?php if (!$launch_cat): ?>
                        <div style="color:#ef4444; font-size:11px; margin-top:4px;">⚠️ Cat. no encontrada:
                            <?php echo esc_html($launch_cat_slug); ?>
                        </div>
                        <?php
            endif; ?>
                    </td>
                    <td style="vertical-align:top; text-align: center;">
                        <?php
            $visibility_map = get_option('endtrack_launch_visibility', array());
            $is_visible = isset($visibility_map[$launch]) ? $visibility_map[$launch] : false;
?>
                        <label class="switch" title="Mostrar/Ocultar a Afiliados">
                            <input type="checkbox" class="endtrack-visibility-toggle"
                                data-launch="<?php echo esc_attr($launch); ?>" <?php checked($is_visible, true); ?>>
                            <span class="slider round"></span>
                        </label>
                    </td>
                    <td style="vertical-align:top;">
                        <span class="badge <?php echo $type_class; ?>">
                            <?php echo $type_label; ?>
                        </span>
                    </td>
                    <td style="vertical-align:top;">
                        <?php echo $render_page_list($registros, 'registro'); ?>
                    </td>
                    <td style="vertical-align:top;">
                        <?php echo $render_page_list($gracias_reg, 'gracias-registro'); ?>
                    </td>
                    <td style="vertical-align:top;">
                        <?php echo $render_page_list($ventas, 'venta'); ?>
                    </td>
                    <td style="vertical-align:top;">
                        <?php echo $render_page_list($gracias, 'gracias'); ?>
                    </td>
                    <td style="vertical-align:top; text-align: center;">
                        <?php
            $dashboards = get_option('endtrack_launch_dashboards', array());
            $dashboard_url = isset($dashboards[$launch]) ? $dashboards[$launch] : false;
?>

                        <div style="margin-bottom: 10px;">
                            <a href="<?php echo esc_url(add_query_arg(array('launch' => $launch), home_url('/endtrack-estadisticas/'))); ?>"
                                target="_blank" class="button button-primary"
                                style="background: #6366f1; border-color: #6366f1; width: 100%; display: flex; align-items: center; justify-content: center; gap: 5px;"
                                title="Ver Estadísticas Pro">
                                <span class="dashicons dashicons-chart-area"></span> Ver Estadísticas
                            </a>
                        </div>

                        <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=endtrack_delete_launch&launch=' . urlencode($launch)), 'endtrack_delete_launch_action', 'endtrack_delete_launch_nonce'); ?>"
                            class="btn-delete-launch" style="color: #f56565; text-decoration: none; font-size: 20px;"
                            title="Borrar Lanzamiento"
                            onclick="return confirm('Seguro que quieres borrar este lanzamiento? Esta opcion NO tiene vuelta atras.');">
                            <span class="dashicons dashicons-trash"></span>
                        </a>
                    </td>
                </tr>
                <?php
        endforeach; ?>
            </tbody>
        </table>
        <p class="description" style="margin-top:20px;">
            <strong>Nota:</strong> Las páginas aparecen aquí automáticamente si tienen asignadas DOS categorías: la del
            <strong>Lanzamiento</strong> y el <strong>Tipo</strong> (registro, venta, gracias).
        </p>
        <script>
            jQuery(document).ready(function ($) {
                var loader = $('#endtrackLoader');
                var aiModal = $('#endtrackAIModal');
                var aiInput = $('#endtrackAIPromptInput');
                var aiConfirmBtn = $('#confirmAIPrompt');
                var aiCancelBtn = $('#closeAIModal');
                var aiModalTitle = $('#endtrackModalTitle');
                var currentAIResolve = null;

                function openAIPromptModal(title, defaultValue = '') {
                    aiModalTitle.text(title);
                    aiInput.val(defaultValue);
                    aiModal.css('display', 'flex');
                    aiInput.focus();

                    return new Promise((resolve) => {
                        currentAIResolve = resolve;
                    });
                }

                aiConfirmBtn.on('click', function () {
                    var val = aiInput.val();
                    aiModal.hide();
                    if (currentAIResolve) currentAIResolve(val);
                });

                aiCancelBtn.on('click', function () {
                    aiModal.hide();
                    if (currentAIResolve) currentAIResolve(null);
                });

                $('.btn-delete-launch').on('click', function (e) {
                    if (!confirm('¿Estás seguro de que deseas eliminar permanentemente este lanzamiento? Se borrarán todos los datos de seguimiento asociados en la base de datos.')) {
                        e.preventDefault();
                    }
                });

                // Granular AI Regeneration (Single Page)
                $(document).on('click', '.btn-ai-page', async function (e) {
                    var self = $(this);
                    var postId = self.data('post-id');
                    var pageType = self.data('type');
                    var pageTitle = self.data('title');

                    var userPrompt = await openAIPromptModal("PÁGINA: " + pageTitle);

                    if (userPrompt === null) return;

                    loader.css('display', 'flex');

                    $.ajax({
                        type: 'POST',
                        url: ajaxurl,
                        data: {
                            action: 'endtrack_regenerate_copy',
                            post_id: postId,
                            page_type: pageType,
                            custom_prompt: userPrompt,
                            nonce: '<?php echo wp_create_nonce("endtrack_regenerate_copy_nonce"); ?>'
                        },
                        success: function (response) {
                            loader.hide();
                            if (response.success) {
                                alert(response.data.message);
                                location.reload();
                            } else {
                                alert('Error: ' + response.data);
                            }
                        },
                        error: function () {
                            loader.hide();
                            alert('Error de conexión.');
                        }
                    });
                });

                $('.endtrack-affiliate-toggle').on('change', function () {
                    var self = $(this);
                    var postId = self.data('post-id');
                    var isActive = self.is(':checked') ? 1 : 0;

                    self.prop('disabled', true);

                    $.ajax({
                        type: 'POST',
                        url: ajaxurl,
                        data: {
                            action: 'endtrack_toggle_affiliate_link',
                            post_id: postId,
                            active: isActive
                        },
                        success: function (response) {
                            self.prop('disabled', false);
                            if (!response.success) {
                                alert('Error: ' + response.data);
                            }
                        },
                        error: function () {
                            self.prop('disabled', false);
                            alert('Error de conexión.');
                        }
                    });
                });

                $('.endtrack-visibility-toggle').on('change', function () {
                    var self = $(this);
                    var launchName = self.data('launch');
                    var isVisible = self.is(':checked') ? 1 : 0;

                    self.prop('disabled', true);

                    $.ajax({
                        type: 'POST',
                        url: ajaxurl,
                        data: {
                            action: 'endtrack_toggle_visibility',
                            launch: launchName,
                            visible: isVisible,
                            nonce: '<?php echo wp_create_nonce('endtrack_toggle_visibility_nonce'); ?>'
                        },
                        success: function (response) {
                            self.prop('disabled', false);
                            if (!response.success) {
                                alert('Error: ' + response.data);
                                self.prop('checked', !isVisible); // Revert
                            }
                        },
                        error: function () {
                            self.prop('disabled', false);
                            alert('Error de conexión.');
                            self.prop('checked', !isVisible); // Revert
                        }
                    });
                });
            });
        </script>
        <?php
    else: ?>
        <div style="padding: 40px; text-align: center; color: #64748B;">
            <span class="dashicons dashicons-calendar-alt"
                style="font-size: 48px; width: 48px; height: 48px; margin-bottom: 16px; opacity: 0.5;"></span>
            <p style="font-size: 16px; margin: 0;">No hay lanzamientos activos.</p>
            <p style="font-size: 14px; margin-top: 8px;">Crea uno arriba para empezar.</p>
        </div>
        <?php
    endif; ?>
    </div>

    <?php
elseif ($active_tab == 'texts'): ?>
    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
        <input type="hidden" name="action" value="endtrack_save_texts">
        <?php wp_nonce_field('endtrack_save_texts_action', 'endtrack_save_texts_nonce'); ?>
        <?php
    $texts = get_option('endtrack_texts', array());
    $defaults = array(
        'welcome_title' => 'Hola {user}, bienvenid@ a la página de admin de afiliados',
        'welcome_subtitle' => 'Tu correo de afiliación de admin es: {email}',
        'panel_welcome_title' => 'Hola {user}, bienvenid@ a tu área de afiliado',
        'panel_welcome_subtitle' => 'Tu email de afiliado: {email}',
        'panel_txt_links_reg' => 'Enlace de Registro',
        'panel_txt_links_venta' => 'Enlace de Venta Directa',
        'panel_txt_leads' => 'Leads Conseguidos',
        'panel_txt_sales' => 'Ventas',
        'panel_txt_commissions' => 'Comisiones (€)',
        'panel_txt_links' => 'Tus Enlaces',
        'wf_taxonomy' => 'wf_page_folders',
        'template_venta' => '',
        'template_gracias_compra' => '',
        'template_registro' => '',
        'template_gracias_reg' => '',
        'logo_admin_panel' => '',
        'logo_user_panel' => '',
    );
    foreach ($defaults as $key => $val) {
        if (!isset($texts[$key]))
            $texts[$key] = $val;
    }

    $templates = get_posts(array(
        'post_type' => 'elementor_library',
        'posts_per_page' => -1,
        'post_status' => 'publish'
    ));
?>

        <div class="settings-grid">
            <!-- Section: Admin Panel -->
            <div class="settings-section-card">
                <div class="settings-section-header">
                    <span class="dashicons dashicons-admin-generic" style="color: var(--endtrack-primary);"></span>
                    <h3>Panel de Administración (Tuyo)</h3>
                </div>
                <div class="settings-section-content">
                    <div class="settings-row">
                        <label>Bienvenida (Título)</label>
                        <input type="text" name="texts[welcome_title]"
                            value="<?php echo esc_attr($texts['welcome_title']); ?>" class="endtrack-input">
                    </div>
                    <div class="settings-row">
                        <label>Bienvenida (Subtítulo)</label>
                        <input type="text" name="texts[welcome_subtitle]"
                            value="<?php echo esc_attr($texts['welcome_subtitle']); ?>" class="endtrack-input">
                    </div>
                    <div class="settings-row">
                        <label>Logo Admin (URL)</label>
                        <input type="text" name="texts[logo_admin_panel]"
                            value="<?php echo esc_attr($texts['logo_admin_panel']); ?>" class="endtrack-input"
                            placeholder="https://...">
                    </div>
                </div>
            </div>

            <!-- Section: User Panel -->
            <div class="settings-section-card">
                <div class="settings-section-header">
                    <span class="dashicons dashicons-groups" style="color: var(--endtrack-primary);"></span>
                    <h3>Panel de Usuario (Afiliados)</h3>
                </div>
                <div class="settings-section-content">
                    <div class="settings-row">
                        <label>Bienvenida (Título)</label>
                        <input type="text" name="texts[panel_welcome_title]"
                            value="<?php echo esc_attr($texts['panel_welcome_title']); ?>" class="endtrack-input">
                    </div>
                    <div class="settings-row">
                        <label>Bienvenida (Subtítulo)</label>
                        <input type="text" name="texts[panel_welcome_subtitle]"
                            value="<?php echo esc_attr($texts['panel_welcome_subtitle']); ?>" class="endtrack-input">
                    </div>
                    <div class="settings-row">
                        <label>Logo Usuario (URL)</label>
                        <input type="text" name="texts[logo_user_panel]"
                            value="<?php echo esc_attr($texts['logo_user_panel']); ?>" class="endtrack-input"
                            placeholder="https://...">
                    </div>
                </div>
            </div>

            <!-- Section: Labels -->
            <div class="settings-section-card">
                <div class="settings-section-header">
                    <span class="dashicons dashicons-translation" style="color: var(--endtrack-primary);"></span>
                    <h3>Etiquetas y Textos del Panel</h3>
                </div>
                <div class="settings-section-content">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="settings-row">
                            <label>Label: Registro</label>
                            <input type="text" name="texts[panel_txt_links_reg]"
                                value="<?php echo esc_attr($texts['panel_txt_links_reg']); ?>" class="endtrack-input">
                        </div>
                        <div class="settings-row">
                            <label>Label: Venta</label>
                            <input type="text" name="texts[panel_txt_links_venta]"
                                value="<?php echo esc_attr($texts['panel_txt_links_venta']); ?>" class="endtrack-input">
                        </div>
                        <div class="settings-row">
                            <label>Label: Leads</label>
                            <input type="text" name="texts[panel_txt_leads]"
                                value="<?php echo esc_attr($texts['panel_txt_leads']); ?>" class="endtrack-input">
                        </div>
                        <div class="settings-row">
                            <label>Label: Ventas</label>
                            <input type="text" name="texts[panel_txt_sales]"
                                value="<?php echo esc_attr($texts['panel_txt_sales']); ?>" class="endtrack-input">
                        </div>
                        <div class="settings-row">
                            <label>Label: Comisiones</label>
                            <input type="text" name="texts[panel_txt_commissions]"
                                value="<?php echo esc_attr($texts['panel_txt_commissions']); ?>" class="endtrack-input">
                        </div>
                        <div class="settings-row">
                            <label>Título Enlaces</label>
                            <input type="text" name="texts[panel_txt_links]"
                                value="<?php echo esc_attr($texts['panel_txt_links']); ?>" class="endtrack-input">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Full Width Sections -->
        <div class="settings-section-card full-width-editor" style="margin-top: 24px;">
            <div class="settings-section-header">
                <span class="dashicons dashicons-format-aside" style="color: var(--endtrack-primary);"></span>
                <h3>Contenido Personalizado (Creatividades)</h3>
            </div>
            <div class="settings-section-content">
                <p class="description" style="margin-bottom: 20px;">Define las creatividades que verán los afiliados.
                    Puedes definir unas globales o específicas por lanzamiento.</p>

                <div class="creative-tabs-container"
                    style="border: 1px solid var(--endtrack-border); border-radius: 12px; overflow: hidden;">
                    <?php
    $all_launches_creatives = array_merge(['global'], $launches);
    $active_creative_tab = isset($_GET['creative_tab']) ? sanitize_text_field($_GET['creative_tab']) : 'global';
?>
                    <div class="creative-tabs-nav"
                        style="display: flex; background: #f1f5f9; border-bottom: 1px solid var(--endtrack-border);">
                        <?php foreach ($all_launches_creatives as $lc):
        $is_active = ($active_creative_tab == $lc);
        $label = ($lc == 'global') ? '🌍 Global/Fallback' : '🚀 ' . ucfirst($lc);
        $tab_url = add_query_arg('creative_tab', $lc);
?>
                        <a href="<?php echo esc_url($tab_url); ?>#creative-editor"
                            style="padding: 12px 20px; text-decoration: none; font-weight: 600; color: <?php echo $is_active ? 'var(--endtrack-primary)' : 'var(--endtrack-text-muted)'; ?>; border-bottom: 2px solid <?php echo $is_active ? 'var(--endtrack-primary)' : 'transparent'; ?>; background: <?php echo $is_active ? '#fff' : 'transparent'; ?>;">
                            <?php echo esc_html($label); ?>
                        </a>
                        <?php
    endforeach; ?>
                    </div>

                    <div id="creative-editor" style="padding: 20px;">
                        <label style="display: block; margin-bottom: 10px;"><strong>Editando creatividades para:
                                <?php echo ($active_creative_tab == 'global') ? 'Global' : ucfirst($active_creative_tab); ?>
                            </strong></label>
                        <?php
    $editor_id = ($active_creative_tab == 'global') ? 'content_creatividades' : 'content_creatividades_' . $active_creative_tab;
    $content = isset($texts[$editor_id]) ? $texts[$editor_id] : '';
    wp_editor($content, $editor_id, array('textarea_name' => "texts[$editor_id]", 'media_buttons' => true, 'textarea_rows' => 12));
?>
                    </div>
                </div>
            </div>
        </div>

        <div class="settings-section-card full-width-editor" style="margin-top: 24px;">
            <div class="settings-section-header">
                <span class="dashicons dashicons-money-alt" style="color: var(--endtrack-primary);"></span>
                <h3>Métodos de Facturación</h3>
            </div>
            <div class="settings-section-content">
                <p class="description" style="margin-bottom: 20px;">Define las instrucciones de facturación que verán
                    los afiliados.
                    Puedes definir unas globales o específicas por lanzamiento.</p>

                <div class="billing-tabs-container"
                    style="border: 1px solid var(--endtrack-border); border-radius: 12px; overflow: hidden;">
                    <?php
    // Reuse launches array
    $all_launches_billing = array_merge(['global'], $launches);
    $active_billing_tab = isset($_GET['billing_tab']) ? sanitize_text_field($_GET['billing_tab']) : 'global';
?>
                    <div class="billing-tabs-nav"
                        style="display: flex; background: #f1f5f9; border-bottom: 1px solid var(--endtrack-border);">
                        <?php foreach ($all_launches_billing as $lb):
        $is_active = ($active_billing_tab == $lb);
        $label = ($lb == 'global') ? '🌍 Global/Fallback' : '🚀 ' . ucfirst($lb);
        $tab_url = add_query_arg('billing_tab', $lb);
?>
                        <a href="<?php echo esc_url($tab_url); ?>#billing-editor"
                            style="padding: 12px 20px; text-decoration: none; font-weight: 600; color: <?php echo $is_active ? 'var(--endtrack-primary)' : 'var(--endtrack-text-muted)'; ?>; border-bottom: 2px solid <?php echo $is_active ? 'var(--endtrack-primary)' : 'transparent'; ?>; background: <?php echo $is_active ? '#fff' : 'transparent'; ?>;">
                            <?php echo esc_html($label); ?>
                        </a>
                        <?php
    endforeach; ?>
                    </div>

                    <div id="billing-editor" style="padding: 20px;">
                        <label style="display: block; margin-bottom: 10px;"><strong>Editando facturación para:
                                <?php echo ($active_billing_tab == 'global') ? 'Global' : ucfirst($active_billing_tab); ?>
                            </strong></label>
                        <?php
    $billing_editor_id = ($active_billing_tab == 'global') ? 'content_billing_methods' : 'content_billing_methods_' . $active_billing_tab;
    $content_billing = isset($texts[$billing_editor_id]) ? $texts[$billing_editor_id] : '';
    wp_editor($content_billing, $billing_editor_id, array('textarea_name' => "texts[$billing_editor_id]", 'media_buttons' => true, 'textarea_rows' => 12));
?>
                    </div>
                </div>
            </div>
        </div>

        <div class="settings-section-card full-width-editor" style="margin-top: 24px;">
            <div class="settings-section-header">
                <span class="dashicons dashicons-editor-help" style="color: var(--endtrack-primary);"></span>
                <h3>Pestaña "Asignación / Ayuda" (Común)</h3>
            </div>
            <div class="settings-section-content">
                <?php wp_editor($texts['content_asignacion'], 'content_asignacion', array('textarea_name' => 'texts[content_asignacion]', 'media_buttons' => true, 'textarea_rows' => 10)); ?>
            </div>
        </div>

        <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid var(--endtrack-border);">
            <button type="submit" class="btn-primary" style="padding: 15px 40px; font-size: 16px;">Guardar Toda la
                Configuración</button>
        </div>
    </form>

    <?php
elseif ($active_tab == 'integrations'): ?>
    <form method="POST" action="<?php echo admin_url('admin-post.php'); ?>">
        <input type="hidden" name="action" value="endtrack_save_integrations">
        <?php wp_nonce_field('endtrack_save_integrations_action', 'endtrack_save_integrations_nonce'); ?>

        <div class="endtrack-card">
            <h2><span class="dashicons dashicons-admin-plugins" style="margin-right: 8px;"></span>Integraciones Externas
            </h2>

            <!-- Claude (Anthropic) Integration -->
            <div
                style="background: #fef7f0; padding: 20px; border-radius: 8px; margin-bottom: 30px; border-left: 4px solid #d97706;">
                <h3 style="margin-top: 0; color: #92400e;">
                    <span class="dashicons dashicons-superhero" style="margin-right: 8px;"></span>
                    Claude AI (Anthropic) — Edición Inteligente de Páginas
                </h3>
                <p style="color: #64748b; margin-bottom: 20px;">
                    Conecta con Claude para generar copy, editar diseño y modificar páginas de Elementor de forma
                    inteligente.
                    <a href="https://console.anthropic.com/settings/keys" target="_blank" style="color: #d97706;">Obtén
                        tu API
                        Key aquí →</a>
                </p>

                <div class="form-group">
                    <label for="anthropic_key">
                        <strong>Anthropic API Key</strong>
                        <span style="color: #dc2626;">*</span>
                    </label>
                    <input type="password" id="anthropic_key" name="anthropic_key"
                        value="<?php echo esc_attr($texts['anthropic_key'] ?? ''); ?>" placeholder="sk-ant-..."
                        class="endtrack-input" style="font-family: monospace;">
                    <small style="color: #64748b;">
                        Tu API key se almacena de forma segura. Formato: sk-ant-...
                    </small>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="claude_model"><strong>Modelo de Claude</strong></label>
                    <select id="claude_model" name="claude_model" class="endtrack-input">
                        <?php
    $current_model = $texts['claude_model'] ?? 'claude-sonnet-4-6';
    $models = array(
        'claude-haiku-4-5-20251001' => 'Haiku 4.5 — Solo para cambios de texto (~4x más barato)',
        'claude-sonnet-4-6' => 'Sonnet 4.6 — Recomendado para generar páginas',
    );
    foreach ($models as $value => $label) {
        $selected = selected($current_model, $value, false);
        echo "<option value=\"{$value}\" {$selected}>{$label}</option>";
    }
?>
                    </select>
                    <small style="color: #64748b;">
                        <strong>Recomendado:</strong> Sonnet 4.5+ para crear páginas desde cero. Haiku solo para cambios
                        menores de texto.
                    </small>
                </div>
            </div>

            <!-- Grafana Integration Removed -->

        </div>

        <div style="text-align: center; margin-top: 30px;">
            <button type="submit" class="btn-primary" style="padding: 15px 40px; font-size: 16px;">
                Guardar Integraciones
            </button>
        </div>
    </form>

    <?php
elseif ($active_tab == 'help'): ?>
    <div class="endtrack-card">
        <h2><span class="dashicons dashicons-book-alt" style="margin-right: 8px;"></span>Guía Maestra y Novedades del
            Sistema</h2>

        <div class="instruction-step" style="border-left: 4px solid #10b981; background: #ecfdf5;">
            <div class="step-number" style="background: #10b981;">N</div>
            <div>
                <strong>🚀 Creación Automática de Lanzamientos</strong>
                <p>Ahora crear un lanzamiento es tan fácil como escribir el nombre y pulsar un botón. El sistema se
                    encarga de todo:</p>
                <ul style="list-style-type: '🍕'; padding-left: 20px;">
                    <li style="padding-left: 10px; margin-bottom: 5px;"><strong>Crea automáticamente todas las
                            páginas:</strong> Registro, Gracias Registro, Venta y Gracias Compra.</li>
                    <li style="padding-left: 10px; margin-bottom: 5px;"><strong>Clona tus plantillas de
                            Elementor:</strong> Copia el diseño, los estilos y la configuración responsive de las
                        plantillas base que hayas definido en "Textos y Configuración".</li>
                    <li style="padding-left: 10px; margin-bottom: 5px;"><strong>Asigna categorías e IDs:</strong>
                        Etiqueta cada página con su función (<code>venta</code>, <code>registro</code>, etc.) y la
                        categoría del lanzamiento (ej. <code>marzo2025</code>).</li>
                    <li style="padding-left: 10px; margin-bottom: 5px;"><strong>Crea carpetas en Wicked
                            Folders:</strong> Organiza las páginas en una carpeta dedicada para que no se pierdan.</li>
                </ul>
            </div>
        </div>

        <div class="instruction-step">
            <div class="step-number">1</div>
            <div>
                <strong>Plantillas de Elementor</strong>
                <p>Para que la magia funcione, debes tener configuradas las <strong>IDs de tus plantillas base</strong>
                    en la pestaña "Textos y Configuración".</p>
                <p>El sistema usará estas plantillas como molde. Si actualizas la plantilla base en Elementor, los
                    futuros lanzamientos heredarán esos cambios.</p>
            </div>
        </div>

        <div class="instruction-step">
            <div class="step-number">2</div>
            <div>
                <strong>Acceso Inmediato para Afiliados</strong>
                <p>Cuando un afiliado se registra a través de cualquiera de tus formularios de captación,
                    <strong>automáticamente obtiene acceso al Panel de Afiliado</strong>.
                </p>
                <p>No hace falta aprobación manual. El sistema detecta el registro, asigna el rol y le muestra su panel
                    personalizado al instante.</p>
            </div>
        </div>

        <div>
            <div class="step-number">3</div>
            <strong>Estadísticas Nativas</strong>
            <p>Accede al botón "Ver Panel" en cada lanzamiento para ver las métricas en tiempo real sin salir de tu web.
            </p>
        </div>

        <div class="instruction-step">
            <div class="step-number">4</div>
            <div>
                <strong>Configuración Técnica (IDs y Shortcodes)</strong>
                <p>Recuerda las reglas de oro para que el rastreo no falle:</p>
                <ul>
                    <li>Botón de registro en Elementor: ID <code>add_suscrito</code>.</li>
                    <li>Shortcode para mostrar el panel de afiliado en el frontend:
                        <code>[endtrack_affiliate_panel]</code>.
                    </li>
                    <li>Shortcode para el panel de administración de afiliados: <code>[endtrack_admin_dashboard]</code>
                        (solo visible para admins).</li>
                </ul>
            </div>
        </div>
    </div>
    <?php
endif; ?>
</div>

<!-- Loader OUTSIDE all wrapper divs so position:fixed works correctly -->
<div id="endtrack-creation-loader">
    <div class="pizza-spinner">🍕</div>
    <h1>se está creando todo el lanzamiento en menos de lo que Juan se come un trozo de pizza.</h1>
</div>

<!-- AI Queue Progress Overlay -->
<div id="endtrack-ai-queue-overlay">
    <div class="queue-content">
        <div class="queue-icon">🧠</div>
        <h2>Generando contenido con IA</h2>
        <p class="queue-status" id="queue-status-text">Preparando...</p>
        <div class="queue-progress-bar">
            <div class="queue-progress-fill" id="queue-progress-fill"></div>
        </div>
        <p style="font-size: 0.85rem; opacity: 0.6;">No cierres esta página. Cada página tarda ~90 segundos.</p>
        <div class="queue-log" id="queue-log"></div>
    </div>
</div>

<?php
// Check if there are pending AI queue tasks
$endtrack_ai_queue = get_option('endtrack_ai_queue', array());
$has_pending_queue = false;
if (!empty($endtrack_ai_queue)) {
    foreach ($endtrack_ai_queue as $qt) {
        if ($qt['status'] === 'pending' || $qt['status'] === 'processing') {
            $has_pending_queue = true;
            break;
        }
    }
}
?>
<?php if ($has_pending_queue): ?>
<script>
    (function () {

        var overlay = document.getElementById('endtrack-ai-queue-overlay');
        var statusEl = document.getElementById('queue-status-text');
        var fillEl = document.getElementById('queue-progress-fill');
        var logEl = document.getElementById('queue-log');
        var nonce = '<?php echo wp_create_nonce("endtrack_ai_queue_nonce"); ?>';

        // Hide the pizza loader if it was showing
        var pizzaLoader = document.getElementById('endtrack-creation-loader');
        if (pizzaLoader) pizzaLoader.style.display = 'none';

        // Show queue overlay
        overlay.style.display = 'flex';

        function addLog(text, type) {
            var entry = document.createElement('div');
            entry.className = 'queue-log-entry ' + (type || '');
            entry.textContent = text;
            logEl.appendChild(entry);
            logEl.scrollTop = logEl.scrollHeight;
        }

        var lastCompleted = 0;

        function finishQueue() {
            statusEl.textContent = '¡Todas las páginas generadas!';
            fillEl.style.width = '100%';
            addLog('🎉 ¡Todo completado!', 'success');
            setTimeout(function () {
                overlay.style.display = 'none';
                window.location.href = window.location.pathname + '?page=endtrack&message=ai_generation_complete';
            }, 2500);
        }

        function poll() {
            var formData = new FormData();
            formData.append('action', 'endtrack_process_ai_queue');
            formData.append('nonce', nonce);

            fetch(ajaxurl, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            })
            .then(function (r) { return r.json(); })
            .then(function (resp) {
                if (!resp.success) {
                    addLog('❌ Error: ' + (resp.data || 'desconocido'), 'error');
                    setTimeout(poll, 5000);
                    return;
                }

                var d = resp.data;

                // Update progress bar
                if (d.total) {
                    var pct = Math.round((d.completed / d.total) * 100);
                    fillEl.style.width = pct + '%';
                    statusEl.textContent = d.completed + ' de ' + d.total + ' páginas procesadas';
                }

                // Log newly completed tasks
                if (d.last_done && d.completed > lastCompleted) {
                    addLog('✅ ' + d.last_done + ' — completada', 'success');
                }
                lastCompleted = d.completed || lastCompleted;

                if (d.status === 'empty' || d.status === 'all_done') {
                    finishQueue();
                    return;
                }

                if (d.status === 'rate_limited') {
                    var waitSec = d.wait || 65;
                    addLog('⏳ Límite de API. Esperando ' + waitSec + 's...', 'processing');
                    var countdown = waitSec;
                    var ci = setInterval(function () {
                        countdown--;
                        statusEl.textContent = 'Esperando ' + countdown + 's por límite de API...';
                        if (countdown <= 0) { clearInterval(ci); poll(); }
                    }, 1000);
                    return;
                }

                if (d.status === 'started') {
                    addLog('⏳ Procesando: ' + (d.task_title || '...'), 'processing');
                }

                // 'started' or 'working' — poll again in 5s
                setTimeout(poll, 5000);
            })
            .catch(function () {
                // Network error — just retry
                setTimeout(poll, 5000);
            });
        }

        // Start
        addLog('🚀 Iniciando generación con IA...', 'processing');
        setTimeout(poll, 1000);
    })();
</script>
<?php
endif; ?>